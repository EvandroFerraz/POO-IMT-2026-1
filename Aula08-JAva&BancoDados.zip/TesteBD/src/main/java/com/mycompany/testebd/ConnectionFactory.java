package com.mycompany.testebd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory {
    private String usuario = "root";
    private String senha = "imtdb";
    private String host = "localhost";
    private String porta = "3306";
    private String bd = "db_pessoas";
    
    public Connection obtemConexao(){
        try{
            // estabelecer conexao
            Connection c = DriverManager.getConnection(
                  //"jdbc:mysql://localhost:3306/db_pessoas
                    "jdbc:mysql://" + host + ":" + porta + "/" + bd,
                    usuario,
                    senha
            );       
            return c;
        }catch(SQLException e){
            return null;
        }
    }       
}
