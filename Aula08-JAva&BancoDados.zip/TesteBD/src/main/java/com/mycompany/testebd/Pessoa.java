package com.mycompany.testebd;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Pessoa {
    private int codigo;
    private String nome;
    private String fone;
    private String email;

    public Pessoa(String nome, String fone, String email) {
        this.nome = nome;
        this.fone = fone;
        this.email = email;
    }
    
    // getters/setters
    // get = metodo de consulta, retorna um atributo
    public int getCodigo(){
        return codigo;
    }
    // set = metodo de modificacao, atualiza o valor do atributo
    public void setCodigo(int codigo){
        this.codigo = codigo;
    }
    public String getNome() {
        return nome;
    }

    public String getFone() {
        return fone;
    }

    public String getEmail() {
        return email;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setFone(String fone) {
        this.fone = fone;
    }

    public void setEmail(String email) {
        this.email = email;
    }
  
    public void inserir(){
        //1: Definir o comando SQL
        String sql = 
                "insert into tb_pessoa(nome,fone,email) values (?,?,?)";
        //2: Estabelecer uma conexão
        ConnectionFactory factory = new ConnectionFactory();
        try(Connection c = factory.obtemConexao()){     
            //3: Transformar a string em um comando SQL
            PreparedStatement ps = c.prepareStatement(sql);
            //4: Preencher os placeholders (dados faltantes)
            ps.setString(1, nome);
            ps.setString(2, fone);
            ps.setString(3, email);
            //5: Executa o comando  
            ps.execute();
        }catch(SQLException e){     
        }   
    }
}
