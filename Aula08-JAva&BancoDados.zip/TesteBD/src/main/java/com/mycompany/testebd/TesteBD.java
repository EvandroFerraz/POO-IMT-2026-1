package com.mycompany.testebd;

import javax.swing.JOptionPane;

public class TesteBD {

    public static void main(String[] args) {
        String menu = "1-Cadastrar\n2-Atualizar\n3-Apagar\n4-Listar\n0-Sair";
        int op;
        
        do{
            op = Integer.parseInt(
                    JOptionPane.showInputDialog(menu)
            );
            switch(op){
                case 1:{
                    String nome = JOptionPane.showInputDialog("Nome?");
                    String fone = JOptionPane.showInputDialog("Fone?");
                    String email = JOptionPane.showInputDialog("Email?");
                    
                    Pessoa p = new Pessoa(nome,fone,email);
                    p.inserir();
                    break;
                }
                case 2:
                    // atualizar
                    break;
                case 3:
                    // apagar
                    break;
                case 4:
                    // listar
                    break;
                case 0:
                    // sair
                    break;
                default:
                    JOptionPane.showMessageDialog(null,"Opção inválida");
            }
        }while(op != 0);
    }
}
